<?php 
	echo "Esto es un PHP script en el servidor";
?>