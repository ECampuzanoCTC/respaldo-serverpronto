
function sendDataTest () {
	var test = "SendMessage.php?target=5525611806&message=Hola%2C+Qué+hace%3F"
	window.location.assign(test);
}
