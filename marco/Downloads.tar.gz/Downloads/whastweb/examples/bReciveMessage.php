<?php
	$pagTitle = "Recibir Mensaje";
	include 'header.php';	
	include 'ReciveMessage.php';
	include 'footer.php';
?>