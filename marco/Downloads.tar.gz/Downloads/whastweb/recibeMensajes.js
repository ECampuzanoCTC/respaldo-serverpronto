j$= jQuery.noConflict();
j$(document).ready(function(){
	// alert('document ready!');
    // j$('#messages').load('http://www.w3schools.com');
 //    j$.ajax({
	//     type: "GET",
	//     url: "http://www.facebook.com",
	//     dataType: "jsonp",
	// }).success( function( data ) {
 //    	j$( '#messages' ).html( data );
	// });
});