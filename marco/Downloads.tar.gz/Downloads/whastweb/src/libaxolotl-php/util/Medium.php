<?php

class Medium
{
    const MAX_VALUE = 0xFFFFFF;    // int
}
