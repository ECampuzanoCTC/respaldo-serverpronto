package test;

import java.io.*;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.HttpEntity;
import org.apache.http.util.*;

import org.apache.http.impl.client.DefaultHttpClient;

public class pruebaUpliad {

	public static void main(String[] args) {
		
		
				//ClientUploadFile clientUploadFile = new ClientUploadFile();
				File inFile = new File("/home/marco/Downloads/modelodatosobras.vsd");
				FileInputStream fis = null;
				try {
				    fis = new FileInputStream(inFile);
				    DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
				    HttpPost httppost = new HttpPost("http://200.38.126.80:80/UploadFile/resources/UploadFile/UploadTFE");
				    MultipartEntity entity = new MultipartEntity();
				    entity.addPart("File", new InputStreamBody(fis, inFile.getName()));
				    entity.addPart("FilePath", new StringBody("/AutomatizacionTFE/0100009682"));
				    
				    httppost.setEntity(entity);
				    
				    System.out.println("Entity : " + entity);
				    System.out.println("http post : " + httppost);
				    HttpResponse response = httpclient.execute(httppost);
				    int statusCode = response.getStatusLine().getStatusCode();
				    HttpEntity responseEntity = response.getEntity();
				    String responseString = EntityUtils.toString(responseEntity, "UTF-8");            
				    System.out.println("CODE : " + statusCode);
				    System.out.println("PATH : " + responseString);
				    try{
				    System.out.println("PATH Descr :" + responseString);
				    }catch(Exception e){}
				} catch (ClientProtocolException e) {
				    System.err.println("No se puede establecer la conexión");
				    e.printStackTrace();
				} catch (IOException e) {
				    System.err.println("Error +++ " + e.getMessage());
				    e.printStackTrace();
				} finally {
				    try {
				        if (fis != null)
				            fis.close();
				    } catch (IOException e) {
				    }

				
		        }    }


}
